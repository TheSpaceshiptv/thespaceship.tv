</main>

<?php wp_footer();?>

<footer class="site-footer"><a href="http://mostly.software">Web design by Mostly.Software</a></footer>

</body></html>